<?php
//plugins/generic/FullSearch/index.php

require_once('FullSearchPlugin.inc.php');
return new FullSearchPlugin();
