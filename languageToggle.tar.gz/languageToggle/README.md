# languageToggle
OJS 3.3.0.13 plugin for changing language with country flags

Preset flags:<br>
![language](https://user-images.githubusercontent.com/114300053/229351919-480585f4-7db7-4176-b6c4-e3cdb50531de.png)
<br> It is still necessary to check if any flags are wrong.
