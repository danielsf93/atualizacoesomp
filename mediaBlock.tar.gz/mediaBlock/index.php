<?php
require_once('mediaBlock.inc.php');
return new mediaBlock();
